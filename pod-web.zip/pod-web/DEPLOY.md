# POD Renew Tool — Hướng dẫn Deploy

## Cách deploy lên Railway (miễn phí, 5 phút)

### Bước 1 — Tạo tài khoản Railway
Vào: https://railway.app → Sign up bằng GitHub

### Bước 2 — Upload code
1. Vào https://railway.app/new
2. Chọn "Empty Project"
3. Click "Add a Service" → "GitHub Repo"
   HOẶC dùng Railway CLI:
   - Cài: npm install -g @railway/cli
   - Login: railway login
   - Deploy: railway up

### Bước 3 — Cài mật khẩu
Trong Railway project → Variables → Add:
  ACCESS_PASSWORD = mật_khẩu_bạn_muốn

### Bước 4 — Lấy URL
Settings → Networking → Generate Domain
→ Bạn có URL dạng: xxx.up.railway.app

### Xong! Vào URL đó, nhập mật khẩu, dùng thôi.

---

## Đổi mật khẩu
Vào Railway → Variables → đổi ACCESS_PASSWORD

## Mật khẩu mặc định (nếu chưa đặt)
pod2024
